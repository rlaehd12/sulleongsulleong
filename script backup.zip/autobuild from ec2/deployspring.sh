#!/bin/bash

docker stop spring-app

docker rm spring-app

docker rmi sulleong104/spring-app:latest

docker run -d -p 8081:50 --network mynetwork --ip 172.18.0.50 -e "spring.datasource.url=jdbc:postgresql://postgres-for-docker:5432/sulleong" -e "spring.datasource.username=sulleong" -e "spring.datasource.password=Sulleong104**" -e "spring.redis.host=redis" -e "server.port=50" --name spring-app sulleong104/spring-app

#!/bin/bash

# 원하는 Nginx 설정 파일 경로
NGINX_CONF_FILE="./my_nginx.conf"

# 컨테이너 이름 또는 ID
CONTAINER_NAME="nginx"

# Nginx 설정 파일을 컨테이너로 복사
docker cp $NGINX_CONF_FILE $CONTAINER_NAME:/etc/nginx/nginx.conf

# Nginx 서버를 다시 시작하여 새로운 설정을 적용
docker exec -it $CONTAINER_NAME nginx -s reload

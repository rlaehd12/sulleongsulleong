#!/bin/bash

docker stop react-app

docker rm react-app

docker rmi sulleong104/react-app

docker run -d -p 3000:80 --network mynetwork --ip 172.18.0.60 --name react-app sulleong104/react-app



REACT_APP_BASE_URL=https://dev.sulleong.site/api
REACT_LOGIN_URL=https://dev.sulleong.site/login/google

#!/bin/bash

# curl로 웹 요청을 보내고 결과를 변수에 저장
response=$(curl -s "https://dev.sulleong.site/api/health-check")

# 변수 출력
echo "Response from the server: $response"

# 응답이 "blue"이면 "ok" 출력, 그 외의 경우 "none" 출력
if [ "$response" == "blue" ]; then
    ansible-playbook -e "check_server=green,check_server_pre=blue" deploy-main-playbook.yml    
else    
    ansible-playbook -e "check_server=blue,check_server_pre=green" deploy-main-playbook.yml    
fi


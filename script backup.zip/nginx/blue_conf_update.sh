#!/bin/bash

# 원하는 결과 값
desired_result="blue"

# 컨테이너에서 CURL 요청을 반복적으로 실행하는 함수

check_health() {
  local result=""
  
  while [ "$result" != "$desired_result" ]; do
    # 컨테이너 내부에서 CURL 요청 실행
    result=$(docker exec -it spring-app-blue curl -s localhost:50/api/health-check)
    
    if [ "$result" == "$desired_result" ]; then
      break
    else
      echo "Current result: '$result'. Waiting for '$desired_result'..."
      sleep 0.1  # 1초 간격으로 재시도
    fi
  done
}

check_health

# 원하는 Nginx 설정 파일 경로
NGINX_CONF_FILE="./blue_nginx.conf"

# 컨테이너 이름 또는 ID
CONTAINER_NAME="nginx"

# Nginx 설정 파일을 컨테이너로 복사
docker cp $NGINX_CONF_FILE $CONTAINER_NAME:/etc/nginx/nginx.conf

# Nginx 서버를 다시 시작하여 새로운 설정을 적용
docker exec -it $CONTAINER_NAME nginx -s reload

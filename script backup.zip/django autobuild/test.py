import pandas as pd
from joblib import load, dump
from sqlalchemy import create_engine
from sklearn.preprocessing import OneHotEncoder

from sqlalchemy.orm import Session
from sqlalchemy import text


engine = create_engine('postgresql://sulleong:Sulleong104**@localhost:5433/sulleong')

# import data review_beer
review_beer = pd.read_sql_query('''SELECT *
    FROM review_beer_join
    WHERE "created_at"
    BETWEEN CURRENT_DATE-1 AND CURRENT_DATE;
    ''', engine)
review_beer = review_beer.drop(columns='created_at')
member_list = list(set(review_beer['member_id']))

if member_list:
  # import data that overlap member
  learning_for_member = pd.read_sql_query(f'''SELECT *
      FROM learning_dataset
      WHERE "member_id"
      IN ({str(member_list)[1:-1]});
      ''', engine)
  
  # review_beer preprocess
  encoder = load('/home/ubuntu/beer_review_encoder.joblib')
  
  # when import joblib
  numeric_data = review_beer.drop(columns=['country', 'large_category', 'sub_category'])
  encoding_beer = encoder.transform(review_beer[['country', 'large_category', 'sub_category']])
  encoded_categories_beer = pd.DataFrame(encoding_beer, columns=encoder.get_feature_names_out(input_features=['country', 'large_category', 'sub_category']))
  review_beer = pd.concat([numeric_data, encoded_categories_beer], axis=1)
  
  # group sum, and merge two dataframe and sum together
  review_beer = review_beer.drop(columns='beer_id')
  sumdata = review_beer.groupby("member_id", group_keys=True).sum()
  sumdata['divide_size'] = review_beer.groupby('member_id').size()
  sumdata = sumdata.reset_index()
  concated = pd.concat([learning_for_member, sumdata])
  final = concated.groupby("member_id", group_keys=True).sum()
  
  # delete existing row, and add new row
  session = Session(engine)
  session.begin()
  try:
      session.execute(text(f"DELETE FROM learning_dataset WHERE member_id IN ({str(member_list)[1:-1]});"))
      final.to_sql('learning_dataset', engine, if_exists='append')
      print('success')
  except Exception as e:
      session.rollback()
      print('rollback', e)
  session.commit()
  session.close()
else:
  print('no data')  
engine.dispose()
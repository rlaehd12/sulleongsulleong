#!/bin/bash

docker stop django-app

docker rm django-app

docker rmi sulleong104/django-app:latest

docker run -d -p 8000:8000 --network mynetwork --ip 172.18.0.99 --name django-app sulleong104/django-app
